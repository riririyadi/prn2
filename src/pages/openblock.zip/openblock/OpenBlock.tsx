import React, { useEffect, useState } from "react";
import { TableGrid } from "../../components/TableGrid";
import { MenuBar } from "../../components/MenuBar";
import { Paging } from "../../components/Paging";
import { OpenNewBlock } from "./OpenNewBlock";

export default function OpenBlock() {
  const column = [
    { column: "MSISDN" },
    { column: "IMSI" },
    { column: "Status" },
    { column: "NDC" },
    { column: "HLR" },
    { column: "Prefix" },
    { column: "Item Description" },
    { column: "Product Description" },
    { column: "Creation Date" },
    { column: "Created By" },
  ];

  const [searchQuery, setSearchQuery] = useState("");
  const [keyword, setKeyword] = useState("");
  const [pageSize, setPageSize] = useState(10);
  const [pageNumber, setPageNumber] = useState(1);
  const [totalRecord, setTotalRecord] = useState(0);
  const [totalRecord1, setTotalRecord1] = useState("-1");
  const [openAdd, setOpenAdd] = useState(false);
  const handleAdd = () => {
    setOpenAdd(true)
  }

  
  

  return (
    <div style={{ padding: "1rem", backgroundColor: "white" }}>
      <MenuBar
        searchQuery={searchQuery}
        setKeyword={setKeyword}
        setPageNumber={setPageNumber}
        setSearchQuery={setSearchQuery}
        handleAdd={handleAdd}
      />
     
      <TableGrid column={column}>
        <tr>
          <td> 234784574839</td>
          <td>09889897832748329</td>
          <td>ALLOCATED</td>
          <td>052</td>
          <td>01</td>
          <td className="text-nowrap">Resource AS</td>
          <td>078362</td>
          <td>3</td>
          <td>12-23-2322</td>
          <td>KayO</td>
        </tr>
        <tr>
          <td className="sticky-col first-col" >234784574839</td>
          <td className="sticky-col second-col">09889897832748329</td>
          <td>ALLOCATED</td>
          <td>052</td>
          <td>01</td>
          <td className="text-nowrap">Resource AS</td>
          <td>078362</td>
          <td>3</td>
          <td>12-23-2322</td>
          <td>KayO</td>
        </tr>
      </TableGrid>
      <Paging
        pageNumber={pageNumber}
        setPageNumber={setPageNumber}
        pageSize={pageSize}
        totalRecord={totalRecord}
      />
      <OpenNewBlock open={openAdd} close={() => setOpenAdd(false)} />
    </div>
  );
}
