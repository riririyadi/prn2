import { FC } from "react";
import { MdClose } from "react-icons/md";
import ModalLevelTwo from "../../components/ModalLevelTwo";

interface IAssignNumberDetailProps {
  open: boolean;
  close: () => void;
}

export const AssignNumberDetail: FC<IAssignNumberDetailProps> = ({
  open,
  close,
}) => {
  return (
    <ModalLevelTwo open={open}>
      <div
        style={{ padding: "1rem", width: "500px", backgroundColor: "white" }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            borderBottom: "1px solid #e8e8e8",
            marginBottom: "10px",
          }}
        >
          <div style={{ textAlign: "left" }}>Assign Number Detail</div>
          <div onClick={close}>
            <MdClose />
          </div>
        </div>
        <div style={{ textAlign: "left" }}> Filter</div>
        <div
          style={{
            display: "flex",
            justifyContent: "start",
            padding: "1rem",
            border: "1px solid #e8e8e8",
          }}
        >
          <div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Type:
              </div>
              <div>
                <select style={{ width: "200px" }}>
                  <option></option>
                  <option value={0}>last serial</option>
                  <option value={1}>range from</option>
                  <option value={2}>upload file</option>
                  <option value={3}>add list</option>
                </select>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Product:
              </div>
              <div>
                <input style={{ width: "70px" }} />
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Item:
              </div>
              <div>
                <input style={{ width: "70px" }} />
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>{" "}
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                NDC:
              </div>
              <div>
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>{" "}
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                HLR:
              </div>
              <div>
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Prefix:
              </div>
              <div>
                <select style={{ width: "200px" }}>
                  <option></option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                </select>
              </div>
              <button>clear</button>
            </div>
          </div>
        </div>
        <div style={{ textAlign: "left" }}>Assign To</div>
        <div
          style={{
            display: "flex",
            justifyContent: "start",
            padding: "1rem",
            border: "1px solid #e8e8e8",
          }}
        >
          <div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Area:
              </div>
              <div>
                <input style={{ width: "70px" }} />
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                Region:
              </div>
              <div>
                <input style={{ width: "70px" }} />
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "75px",
                  textAlign: "right",
                  marginRight: "5px",
                }}
              >
                POC:
              </div>
              <div>
                <input style={{ width: "70px" }} />
                <input />
                <button>lov</button>
                <button>clear</button>
              </div>
            </div>
          </div>
        </div>
        <div
          style={{
            border: "1px solid #e8e8e8",
            display: "flex",
            justifyContent: "center",
            marginTop: '10px'
          }}
        >
          <div>
            <button>Submit</button>
            <button>Close</button>
          </div>
        </div>
      </div>
    </ModalLevelTwo>
  );
};
